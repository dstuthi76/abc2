# Databricks notebook source
# MAGIC %md
# MAGIC # LakeWatch DQ Run
# MAGIC Entry point mirroring the original `dq_run.py`, adapted to:
# MAGIC - take **catalog_name / schema_name** as widgets (config.yaml as fallback)
# MAGIC - run for **all tables** in the schema that have active rules
# MAGIC - promote records passing all row-level rules into
# MAGIC   `ml_cleaned_datasets.<table>` (insert-only MERGE on `cdw_hash_key`)

# COMMAND ----------

import sys, os

# Point this at wherever the dq_framework folder is deployed in your workspace
FRAMEWORK_PATH = os.path.join(os.path.dirname(
    os.path.abspath("__file__")), "dq_framework")
sys.path.append(FRAMEWORK_PATH)
# If running from a fixed workspace path instead, use e.g.:
# sys.path.append("/Workspace/Users/<you>/data_observability_framework/dq_framework")

import yaml
from datetime import datetime, timezone
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("DataQualityChecksApp") \
    .enableHiveSupport() \
    .getOrCreate()

# COMMAND ----------

# Step 1: Load YAML config (defaults) + widgets (overrides)

with open("config.yaml", "r") as file:
    config = yaml.safe_load(file)

dbutils.widgets.text("catalog_name", config.get("catalog", "cdw_dev"), "")
dbutils.widgets.text("schema_name", config.get("source_schema", ""), "")
dbutils.widgets.text("table_name", str(config.get("table_name") or ""), "")
dbutils.widgets.text("cleaned_catalog", config.get("cleaned_catalog"), "")
dbutils.widgets.text("cleaned_schema", config.get("cleaned_schema", ""))
catalog_name = dbutils.widgets.get("catalog_name").strip()
schema_name  = dbutils.widgets.get("schema_name").strip()
table_name   = dbutils.widgets.get("table_name").strip() or None

config_catalog  = config.get("config_catalog", "cdw_dev")
config_schema   = config.get("config_schema", "domain_config")
result_catalog  = config.get("result_catalog", "cdw_dev")
result_schema   = config.get("result_schema", "domain_config")
cleaned_catalog = dbutils.widgets.get("cleaned_catalog").strip()
cleaned_schema  = dbutils.widgets.get("cleaned_schema").strip()

compute_table_metrics  = bool(config.get("compute_table_metrics", True))
compute_column_metrics = bool(config.get("compute_column_metrics", True))
compute_kpi_metrics    = bool(config.get("compute_kpi_metrics", True))

batch_timestamp = datetime.now(timezone.utc)
try:
    job_run_id = dbutils.notebook.entry_point.getDbutils().notebook() \
        .getContext().currentRunId().toString()
except Exception:
    job_run_id = f"manual_{int(batch_timestamp.timestamp())}"

print(f"Run started | catalog={catalog_name} schema={schema_name} "
      f"table={table_name or 'ALL'} batch_ts={batch_timestamp.isoformat()}")

# COMMAND ----------

# Step 2: Execute DQ checks for every rule-bearing table in the schema

from dq_executor import execute_dq_checks

run_summary = execute_dq_checks(
    catalog_name=catalog_name,
    schema_name=schema_name,
    config_catalog=config_catalog,
    config_schema=config_schema,
    result_catalog=result_catalog,
    result_schema=result_schema,
    cleaned_catalog=cleaned_catalog,
    cleaned_schema=cleaned_schema,
    table_name=table_name,
    batch_timestamp=batch_timestamp,
    job_run_id=job_run_id,
    compute_table_metrics=compute_table_metrics,
    compute_column_metrics=compute_column_metrics,
    compute_kpi_metrics=compute_kpi_metrics,
)

print("🏁 Data Quality Execution Completed.")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM cdw_dev.domain_config.dq_logs
# MAGIC ORDER BY batch_timestamp DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM cdw_dev.domain_config.dq_error_logs
# MAGIC ORDER BY batch_timestamp DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM cdw_dev.domain_config.dq_bad_records
# MAGIC ORDER BY batch_timestamp DESC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cdw_dev.domain_config.dq_table_metrics

# COMMAND ----------

dbutils.notebook.run(
    "/Workspace/Users/danduprolu.stuthi@latentview.com/dq_execution_v2/dq_framework/email_alert",
    timeout_seconds=1800,
    arguments={"catalog_name": catalog_name, "schema_name": schema_name,"table_name": table_name,
               "lookback_hours": "24", "dry_run": "false"},
)